package JDB;


import JDB.NewDb;
import JDB.NewForm;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Manage {
    private static JFrame frame = new JFrame();
    public static  void setManage(boolean view){
        frame.setVisible(view);
    }

    public static void manage(Connection connection){
        JButton bt1 = new JButton("管理数据库");
        JButton bt2 = new JButton("管理表单");
        bt1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NewDb.newdb(connection);
                NewDb.setNewDb(true);
                setManage(false);
            }
        });
        bt2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NewForm.newform(connection);
                NewForm.setNewForm(true);
                setManage(false);
            }
        });
        JPanel panel = new JPanel();
        panel.add(bt1);
        panel.add(bt2);
        frame.add(panel);
        frame.setBounds(700, 400, 300, 300);
        frame.addWindowListener(new WindowAdapter() {     //设置界面关闭监听时间
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
