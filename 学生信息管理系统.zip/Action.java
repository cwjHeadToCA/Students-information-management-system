package JDB;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Action {
    static Statement st = null;//创建对象，用来执行不带参数的SQL查询和更新
    static PreparedStatement pre = null;//创建对象，用来执行带参数的SQL语句


    public static ResultSet select(Connection connection,String sql){
        ResultSet rs = null;
        try {
            Statement sm = connection.createStatement();
            rs=sm.executeQuery(sql); // 执行数据查询语句(select)
            // sm.executeUpdate(sql); // 执行数据更新语句(delete、update、insert、drop等)statement.close();
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return rs;
    }
    public static void update(Connection connection,String sql){
        try {
            Statement sm = connection.createStatement();
            sm.executeUpdate(sql);

        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public static void insert(Connection connection,String sql){
        try {
            Statement sm = connection.createStatement();
            sm.executeUpdate(sql);
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    public static void delete(Connection connection,String sql){
        try{
            Statement sm= connection.createStatement();
            sm.executeUpdate(sql);
        }catch(Exception e){
            System.out.println(e.toString());
        }
    }

    public static void newdb(Connection connection,String sql){
        try{
            Statement sm= connection.createStatement();
            sm.execute(sql);
        }catch(Exception e){
            System.out.println(e.toString());
        }
    }
}
