package JDB;

import JDB.Action;
import JDB.Manage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class NewDb {
    private static JFrame frame = new JFrame();
    public static  void setNewDb(boolean view){
        frame.setVisible(view);
    }

        public static void newdb(Connection connection){
            JButton bt1 = new JButton("新建");
            JButton bt2 = new JButton("返回");
            JTextField text = new JTextField(20);
            JLabel label = new JLabel("数据库名称");
            JPanel panel = new JPanel();
            panel.add(label);
            panel.add(text);
            panel.add(bt1);
            panel.add(bt2);
            bt1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String name = text.getText();
                    newdb(connection,"create database "+name);

                }
            });
            bt2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    setNewDb(false);
                    Manage.setManage(true);
                }
            });
            frame.add(panel);
            frame.setBounds(700, 400, 300, 300);
        }
        public static void newdb(Connection connection,String sql){
            try{
                Statement statement= connection.createStatement();
                statement.execute(sql);
            }catch(Exception e){
                System.out.println(e.toString());
            }
        }
}
