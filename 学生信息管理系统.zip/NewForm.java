package JDB;

import JDB.Action;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;

public class NewForm {
    private static JFrame frame = new JFrame();
    public static  void setNewForm(boolean view){
        frame.setVisible(view);
    }

    public static void newform(Connection connection){
        JButton bt1 = new JButton("新建");
        JButton bt2 = new JButton("返回");
        JButton bt3 = new JButton("删除表");
        JButton bt4 = new JButton("删除列");
        JButton bt5 =new JButton("新增列");
        TextField text = new TextField(20);
        TextField text1 = new TextField(20);
        TextField text2 = new TextField(20);
        JLabel label = new JLabel("数据库名称");
        JLabel label1 = new JLabel("数据表名称");
        JLabel label2 = new JLabel("数据列名称");
        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(text);
        panel.add(label1);
        panel.add(text1);
        panel.add(label2);
        panel.add(text2);
        panel.add(bt1);
        panel.add(bt3);
        panel.add(bt4);
        panel.add(bt5);
        panel.add(bt2);
        bt1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dbname = text.getText();
                String formname = text1.getText();
                String cl = text2.getText();
                JDB.Action.insert(connection,"use "+dbname +"; create table "+formname+"("+cl+")");

            }
        });
        bt2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setNewForm(false);
                JDB.Manage.setManage(true);
            }
        });
        bt3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dbname = text.getText();
                String formname = text1.getText();
                JDB.Action.delete(connection,"use "+dbname+" drop table "+formname);
            }
        });
        bt4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dbname = text.getText();
                String formname = text1.getText();
                String cl = text2.getText();
                JDB.Action.insert(connection,"use "+dbname+" alter table "+formname+" drop column "+cl);
            }
        });
        bt5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dbname = text.getText();
                String formname = text1.getText();
                String cl = text2.getText();
                Action.insert(connection,"use "+dbname+" alter table "+formname+" add "+cl);
            }
        });
        frame.add(panel);
        frame.setBounds(700, 400, 300, 300);
        frame.addWindowListener(new WindowAdapter() {     //设置界面关闭监听时间
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
