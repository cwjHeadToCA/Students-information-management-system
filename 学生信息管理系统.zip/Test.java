//package JDB;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class Test extends JFrame{
//	Panel panel1,panel2,panel3,panel4,panel5,panel6,panel7,panel8,panel9;
//    JLabel Sno,Sname,Sage,Sdept,Ssex,Cno,Cname,preCourse,Credit,scSno,scCno,Grade,message,message1,message2,message3,message4;
//    TextField SnoText,SnameText,SageText,SdeptText,SsexText,
//            CnoText,CnameText,preCourseText,CreditText,scSnoText,scCnoText,GradeText;
//    TextArea inform;
//    JCheckBox table;
//    JRadioButton s1 = new JRadioButton("男", true);
//	JRadioButton s2 = new JRadioButton("女");
//	// 单选按钮的组，放入同一个组就能够实现单选的效果
//	public ButtonGroup g = new ButtonGroup();
//	public ButtonGroup ga = new ButtonGroup();
//	JRadioButton student,course,sc;
//    JButton search,insert,update,delete,manage;
//    Connection connection;
//    PreparedStatement preSearch,preInsert,preUpdate,preDelete;
//    String studentSearch,studentInsert,studentUpdate,studentDelete,studentsex;
//    String courseSearch,courseInsert,courseUpdate,courseDelete;
//    String scSearch,scInsert,scUpdate,scDelete;
//    static JFrame frame=new JFrame("主界面");
//    static void setTest(boolean view){
//        frame.setVisible(view);
//    }
//
//    Test(){
//        String JDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        try{
//            Class.forName(JDriver);
//        }
//        catch (ClassNotFoundException e){
//            System.out.println("加载数据库引擎失败");
//            System.exit(0);
//        }
//
//        table=new JCheckBox();
//        student=new JRadioButton("学生表",true);
//        course=new JRadioButton("课程表",false);
//        sc=new JRadioButton("SC表",false);
//
//        ga.add(student);
//        ga.add(sc);
//        ga.add(course);
//
//        Sno=new JLabel("学号");
//        Sname=new JLabel("姓名");
//        Sage=new JLabel("年龄");
//        Sdept=new JLabel("系别");
//        Ssex=new JLabel("性别");
//        SnoText=new TextField(10);
//        SnameText=new TextField(10);
//        SageText=new TextField(10);
//        SdeptText=new TextField(10);
//        SsexText=new TextField(10);
//
//		// 将男女两个单选按钮加入同一个组中
//		g.add(s1);
//		g.add(s2);
//
//        Cno=new JLabel("课程号");
//        Cname=new JLabel("课程名");
//        preCourse=new JLabel("先行课");
//        Credit=new JLabel("学分");
//        CnoText=new TextField(10);
//        CnameText=new TextField(10);
//        preCourseText=new TextField(10);
//        CreditText=new TextField(10);
//
//        scSno=new JLabel("课程号");
//        scCno=new JLabel("课程名");
//        Grade=new JLabel("成绩");
//        scSnoText=new TextField(10);
//        scCnoText=new TextField(10);
//        GradeText=new TextField(10);
//
//        inform=new TextArea(10,80);
//        message=new JLabel("                                    ");
//        message1=new JLabel("说明：                                                                                                                                                                                                                                                                                                                                                          ");
//        message2=new JLabel("1.本数据库系统基于java语言编写，使用JDBC技术实现与SQL Server 连接，通过idea构建开发平台。");
//        message3=new JLabel("2.本系统操作过程中无需打开SQL Server");
//        message4=new JLabel("3.该系统处处体现了人性化设计，具有一定的实用性和可移植性。")	;
//        inform.setText("欢迎进入学生信息管理系统！"+"\n"+"\n"
//                +"本数据库管理系统不支持级联删除，删除前请注意数据的唯一性！"+"\n"+"\n"
//                +"student支持由学号修改姓名，course支持由课程号修改学分，sc支持由学号和科目修改分数。"+"\n"+"\n"
//                + "student支持由学号删除其他项，course支持由课程号删除其他项，sc支持由学号和课程号删除其他项。");
//
//        search=new JButton("查找");
//        insert=new JButton("插入");
//        update=new JButton("修改");
//        delete=new JButton("删除");
//        manage=new JButton("管理");
//
//        panel1=new Panel();
//        panel2=new Panel();
//        panel3=new Panel();
//        panel4=new Panel();
//        panel5=new Panel();
//        panel6=new Panel();
//        panel7=new Panel();
//        panel8=new Panel();
//        panel9=new Panel();
//
//        panel1.add(student);panel1.add(Sno);panel1.add(SnoText);panel1.add(Sname);panel1.add(SnameText);panel1.add(Sage);
//        panel1.add(SageText);panel1.add(Sdept);panel1.add(SdeptText);panel1.add(Ssex);panel1.add(s1);panel1.add(s2);
//
//        panel2.add(course);panel2.add(Cno);panel2.add(CnoText);panel2.add(Cname);panel2.add(CnameText);
//        panel2.add(preCourse);panel2.add(preCourseText);panel2.add(Credit);panel2.add(CreditText);
//
//        panel3.add(sc);panel3.add(scSno);panel3.add(scSnoText);panel3.add(scCno);panel3.add(scCnoText);panel3.add(Grade);panel3.add(GradeText);
//
//        panel4.add(search);panel4.add(insert);panel4.add(update);panel4.add(delete);panel4.add(manage);
//
//        panel5.add(inform);panel6.add(message1);panel7.add(message2);panel8.add(message3);panel9.add(message4);
//
//        setLayout(new FlowLayout(0,8,8));
//        add(panel1);add(panel2);add(panel3);add(panel4);add(panel5);add(panel6);add(panel7);add(panel8);add(panel9);
//
//        search.addActionListener(new search());
//        insert.addActionListener(new insert());  // 为按钮创建事件
//        update.addActionListener(new update());
//        delete.addActionListener(new delete());
//        manage.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                Manage.manage(connection);
//                Manage.setManage(true);
//                setTest(false);
//            }
//        });
//
//        addWindowListener(new WinClose());
//        setSize(800,560);
//        setTitle("学生信息管理系统");
//        setVisible(true);
//    }
//    class search implements ActionListener{
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            if (student.isSelected()){
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    Statement statement;
//                    ResultSet resultSet;
//                    statement=connection.createStatement();
//                    String sno= SnoText.getText();
//                    String sname= SnameText.getText();
//                    String sdept= SdeptText.getText();
//                    resultSet=statement.executeQuery("SELECT * FROM student where sno like '%"+sno+"%' and sname like '%"+sname+"%' and " +
//                            "sdept like '%"+sdept+"%'");
//                    String str="";
//                    while (resultSet.next()){
//                        str=str+resultSet.getString("Sno")+"\t"+resultSet.getString("Sname")+"\t"+
//                                resultSet.getString("Sage")+"\t"+resultSet.getString("Sdept")+"\t"+resultSet.getString("Ssex")+"\n";
//                    }
//                    inform.setText("数据查询成功，已经显示在控制台窗口！\n"+str);
//                    SnoText.setText("");
//                    SnameText.setText("");
//                    SageText.setText("");
//                    SdeptText.setText("");
//                    SnoText.requestFocus();
//                }
//                catch (SQLException e1){
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//            }
//            else if (course.isSelected()){
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    Statement statement;
//                    ResultSet resultSet;
//                    statement=connection.createStatement();
//                    String cno=CnoText.getText();
//                    String cname=CnameText.getText();
//                    String preCourse=preCourseText.getText();
//                    resultSet=statement.executeQuery("SELECT * FROM course where cno like '%"+cno+"%' and cname like '%"+cname+"%'" +
//                            " and preCourse like '%"+preCourse+"%'");
//                    String str="";
//                    while (resultSet.next()){
//                    	str=str+resultSet.getString("Cno")+","+resultSet.getString("Cname")+","+
//                                resultSet.getString("preCourse")+","+resultSet.getString("Credit")+"\n";
//                    }
//                    inform.setText("数据查询成功，已经显示在控制台窗口！\n"+str);
//                    CnoText.setText("");
//                    CnameText.setText("");
//                    preCourseText.setText("");
//                    CreditText.setText("");
//                    CnoText.requestFocus();
//                }
//                catch (SQLException e1){
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//            }
//            else{
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    Statement statement;
//                    ResultSet resultSet;
//                    statement=connection.createStatement();
//                    String scSno=scSnoText.getText();
//                    String scCno=scCnoText.getText();
//                    String str="";
//                    resultSet=statement.executeQuery("SELECT * FROM sc where scSno like '%"+scSno+"%' and scCno like '%"+scCno+"%'");
//                    while (resultSet.next()){
//                    	str=str+resultSet.getString("scSno")+","+resultSet.getString("scCno")+","+
//                                resultSet.getString("Grade")+"\n";
//                    }
//                    inform.setText("数据查询成功，已经显示在控制台窗口！\n"+str);
//                    scSnoText.setText("");
//                    scCnoText.setText("");
//                    GradeText.setText("");
//                    scSnoText.requestFocus();
//                }
//                catch (SQLException e1){
//                    System.out.println("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//            }
//        }
//    }
//    class insert implements ActionListener{
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            if (student.isSelected()){
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    studentInsert="INSERT INTO student VALUES(?,?,?,?,?)";
//                    preInsert=connection.prepareStatement(studentInsert);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preInsert.setString(1,SnoText.getText());
//                    preInsert.setString(2,SnameText.getText());
//                    preInsert.setInt(3,Integer.parseInt(SageText.getText()));
//                    preInsert.setString(4,SdeptText.getText());
////                    if (male.isSelected())
////                        studentsex="男";
////                    else
////                        studentsex="女";
//                    if (s1.isSelected())
//                        preInsert.setString(5,"男");
//                    else
//                        preInsert.setString(5,"女");
////                    preInsert.setString(5,studentsex);
//                    preInsert.executeUpdate();
//                    inform.setText("插入数据成功");
//                    SnoText.setText("");
//                    SnameText.setText("");
//                    SageText.setText("");
//                    SdeptText.setText("");
//                    SnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    SnoText.requestFocus();
//                }
//            }
//            else if (course.isSelected()){
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    courseInsert="INSERT INTO course VALUES(?,?,?,?)";
//                    preInsert=connection.prepareStatement(courseInsert);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preInsert.setString(1,CnoText.getText());
//                    preInsert.setString(2,CnameText.getText());
//                    preInsert.setString(3,preCourseText.getText());
//                    preInsert.setInt(4,Integer.parseInt(CreditText.getText()));
//                    preInsert.executeUpdate();
//                    inform.setText("插入数据成功");
//                    CnoText.setText("");
//                    CnameText.setText("");
//                    preCourseText.setText("");
//                    CreditText.setText("");
//                    CnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    CnoText.requestFocus();
//                }
//            }
//            else{
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    scInsert="INSERT INTO sc VALUES(?,?,?)";
//                    preInsert=connection.prepareStatement(scInsert);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preInsert.setString(1,scSnoText.getText());
//                    preInsert.setString(2,scCnoText.getText());
//                    preInsert.setInt(3,Integer.parseInt(GradeText.getText()));
//                    preInsert.executeUpdate();
//                    inform.setText("插入数据成功");
//                    scSnoText.setText("");
//                    scCnoText.setText("");
//                    GradeText.setText("");
//                    scSnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    scSnoText.requestFocus();
//                }
//            }
//        }
//    }
//    class update implements ActionListener{
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            if (student.isSelected()){
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";// 数据源
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    studentUpdate="UPDATE student SET Sname=? WHERE Sno=?";
//                    preUpdate=connection.prepareStatement(studentUpdate);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preUpdate.setString(1,SnameText.getText());
//                    preUpdate.setString(2,SnoText.getText());
//                    preUpdate.executeUpdate();
//                    inform.setText("插入数据成功");
//                    SnoText.setText("");
//                    SnameText.setText("");
//                    SageText.setText("");
//                    SdeptText.setText("");
//                    SnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    SnoText.requestFocus();
//                }
//            }
//            else if (course.isSelected()){
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";// 数据源
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    courseUpdate="UPDATE course SET Cname=? WHERE Cno=?";
//                    preUpdate=connection.prepareStatement(courseUpdate);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preUpdate.setString(1,CnameText.getText());
//                    preUpdate.setString(2,CnoText.getText());
//                    preUpdate.executeUpdate();
//                    inform.setText("插入数据成功");
//                    CnoText.setText("");
//                    CnameText.setText("");
//                    preCourseText.setText("");
//                    CreditText.setText("");
//                    CnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    CnoText.requestFocus();
//                }
//            }
//            else {
//                try{
//                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";// 数据源
//                    String user="sa";
//                    String password="sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    scUpdate="UPDATE sc SET Grade=? WHERE scSno=? AND scCno=?";
//                    preUpdate=connection.prepareStatement(scUpdate);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preUpdate.setInt(1,Integer.parseInt(GradeText.getText()));
//                    preUpdate.setString(2,scSnoText.getText());
//                    preUpdate.setString(3,scCnoText.getText());
//                    preUpdate.executeUpdate();
//                    inform.setText("插入数据成功");
//                    scSnoText.setText("");
//                    scCnoText.setText("");
//                    GradeText.setText("");
//                    scSnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    scSnoText.requestFocus();
//                }
//            }
//        }
//    }
//    class delete implements ActionListener{
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            if (student.isSelected()){
//                try{
//                    String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user = "sa";
//                    String password = "sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    studentDelete="DELETE FROM student WHERE Sno=?" ;
//                    preDelete=connection.prepareStatement(studentDelete);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preDelete.setString(1,SnoText.getText());
//                    preDelete.executeUpdate();
//                    inform.setText("删除数据成功!");
//                    SnoText.setText("");
//                    SnameText.setText("");
//                    SageText.setText("");
//                    SdeptText.setText("");
//                    SnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    SnoText.requestFocus();
//                }
//            }
//            else if (course.isSelected()){
//                try{
//                    String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user = "sa";
//                    String password = "sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    courseDelete="DELETE FROM course WHERE Cno=?" ;
//                    preDelete=connection.prepareStatement(courseDelete);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preDelete.setString(1,CnoText.getText());
//                    preDelete.executeUpdate();
//                    inform.setText("删除数据成功!");
//                    CnoText.setText("");
//                    CnameText.setText("");
//                    preCourseText.setText("");
//                    CreditText.setText("");
//                    CnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    CnoText.requestFocus();
//                }
//            }
//            else {
//                try{
//                    String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
//                    String user = "sa";
//                    String password = "sa";
//                    Connection connection=DriverManager.getConnection(connectDB, user, password);
//                    scDelete="DELETE FROM sc WHERE scSno=? AND scCno=?" ;
//                    preDelete=connection.prepareStatement(scDelete);
//                    inform.setText("连接数据库成功"+"\n");
//                }
//                catch (SQLException e1) {
//                    inform.setText("数据库连接错误"+"\n");
//                    System.exit(0);
//                }
//                try{
//                    preDelete.setString(1,scSnoText.getText());
//                    preDelete.setString(2,scCnoText.getText());
//                    preDelete.executeUpdate();
//                    inform.setText("删除数据成功!");
//                    scSnoText.setText("");
//                    scCnoText.setText("");
//                    GradeText.setText("");
//                    scSnoText.requestFocus();
//                }
//                catch (Exception s2) {
//                    inform.setText("输入数据有误！");
//                    scSnoText.requestFocus();
//                }
//            }
//        }
//    }
//    class WinClose extends WindowAdapter {
//        public void windowClosing(WindowEvent e)
//        {
//            (e.getWindow()).dispose();
//            System.exit(0);
//        }
//    }
//}
package JDB;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Test extends JFrame{
    Panel panel1,panel2,panel3,panel4,panel5,panel6,panel7,panel8,panel9;
    JLabel Sno,Sname,Sage,Sdept,Ssex,Cno,Cname,preCourse,Credit,scSno,scCno,Grade,message,message1,message2,message3,message4;
    TextField SnoText,SnameText,SageText,SdeptText,SsexText,
            CnoText,CnameText,preCourseText,CreditText,scSnoText,scCnoText,GradeText;
    TextArea inform;
    JCheckBox table;
    JRadioButton s1 = new JRadioButton("男", true);
    JRadioButton s2 = new JRadioButton("女");
    // 单选按钮的组，放入同一个组就能够实现单选的效果
    public ButtonGroup g = new ButtonGroup();
    public ButtonGroup ga = new ButtonGroup();
    JRadioButton student,course,sc;
    JButton search,insert,update,delete,manage;
    Connection connection;
    PreparedStatement preSearch,preInsert,preUpdate,preDelete;
    String studentSearch,studentInsert,studentUpdate,studentDelete,studentsex;
    String courseSearch,courseInsert,courseUpdate,courseDelete;
    String scSearch,scInsert,scUpdate,scDelete;
    static JFrame frame=new JFrame("主界面");
    static void setTest(boolean view){
        frame.setVisible(view);
    }

    Test(){
        String JDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        try{
            Class.forName(JDriver);
        }
        catch (ClassNotFoundException e){
            System.out.println("加载数据库引擎失败");
            System.exit(0);
        }

        table=new JCheckBox();
        student=new JRadioButton("学生表",true);
        course=new JRadioButton("课程表",false);
        sc=new JRadioButton("SC表",false);

        ga.add(student);
        ga.add(sc);
        ga.add(course);

        Sno=new JLabel("学号");
        Sname=new JLabel("姓名");
        Sage=new JLabel("年龄");
        Sdept=new JLabel("系别");
        Ssex=new JLabel("性别");
        SnoText=new TextField(10);
        SnameText=new TextField(10);
        SageText=new TextField(10);
        SdeptText=new TextField(10);
        SsexText=new TextField(10);

        // 将男女两个单选按钮加入同一个组中
        g.add(s1);
        g.add(s2);

        Cno=new JLabel("课程号");
        Cname=new JLabel("课程名");
        preCourse=new JLabel("先行课");
        Credit=new JLabel("学分");
        CnoText=new TextField(10);
        CnameText=new TextField(10);
        preCourseText=new TextField(10);
        CreditText=new TextField(10);

        scSno=new JLabel("课程号");
        scCno=new JLabel("课程号");
        Grade=new JLabel("成绩");
        scSnoText=new TextField(10);
        scCnoText=new TextField(10);
        GradeText=new TextField(10);

        inform=new TextArea(10,80);
        message=new JLabel("                                    ");
        message1=new JLabel("说明：                                                                                                                                                                                                                                                                                                                                                          ");
        message2=new JLabel("1.本数据库系统基于java语言编写，使用JDBC技术实现与SQL Server 连接，通过idea构建开发平台。");
        message3=new JLabel("2.本系统操作过程中无需打开SQL Server");
        message4=new JLabel("3.该系统处处体现了人性化设计，具有一定的实用性和可移植性。")	;
        inform.setText("欢迎进入学生信息管理系统！"+"\n"+"\n"
                +"本数据库管理系统不支持级联删除，删除前请注意数据的唯一性！"+"\n"+"\n"
                +"student支持由学号修改姓名，course支持由课程号修改课程名，sc支持由学号和科目修改分数。"+"\n"+"\n"
                + "student支持由学号删除其他项，course支持由课程号删除其他项，sc支持由学号和课程号删除其他项。");

        search=new JButton("查找");
        insert=new JButton("插入");
        update=new JButton("修改");
        delete=new JButton("删除");
        manage=new JButton("管理");

        panel1=new Panel();
        panel2=new Panel();
        panel3=new Panel();
        panel4=new Panel();
        panel5=new Panel();
        panel6=new Panel();
        panel7=new Panel();
        panel8=new Panel();
        panel9=new Panel();

        panel1.add(student);panel1.add(Sno);panel1.add(SnoText);panel1.add(Sname);panel1.add(SnameText);panel1.add(Sage);
        panel1.add(SageText);panel1.add(Sdept);panel1.add(SdeptText);panel1.add(Ssex);panel1.add(s1);panel1.add(s2);

        panel2.add(course);panel2.add(Cno);panel2.add(CnoText);panel2.add(Cname);panel2.add(CnameText);
        panel2.add(preCourse);panel2.add(preCourseText);panel2.add(Credit);panel2.add(CreditText);

        panel3.add(sc);panel3.add(scSno);panel3.add(scSnoText);panel3.add(scCno);panel3.add(scCnoText);panel3.add(Grade);panel3.add(GradeText);

        panel4.add(search);panel4.add(insert);panel4.add(update);panel4.add(delete);panel4.add(manage);

        panel5.add(inform);panel6.add(message1);panel7.add(message2);panel8.add(message3);panel9.add(message4);

        setLayout(new FlowLayout(0,8,8));
        add(panel1);add(panel2);add(panel3);add(panel4);add(panel5);add(panel6);add(panel7);add(panel8);add(panel9);

        search.addActionListener(new search());
        insert.addActionListener(new insert());  // 为按钮创建事件
        update.addActionListener(new update());
        delete.addActionListener(new delete());
        manage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                String user="sa";
                String password="sa";
                try {
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    Manage.manage(connection);
                    Manage.setManage(true);
                    setTest(false);
                } catch (SQLException e1){
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }

            }
        });

        addWindowListener(new WinClose());
        setSize(800,560);
        setTitle("学生信息管理系统");
        setVisible(true);
    }
    class search implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if (student.isSelected()){
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    Statement statement;
                    ResultSet resultSet;
                    statement=connection.createStatement();
                    String sno= SnoText.getText();
                    String sname= SnameText.getText();
                    String sdept= SdeptText.getText();
                    resultSet=statement.executeQuery("SELECT * FROM student where sno like '%"+sno+"%' and sname like '%"+sname+"%' and " +
                            "sdept like '%"+sdept+"%'");
                    String str="";
                    while (resultSet.next()){
                        str=str+resultSet.getString("Sno")+"\t"+resultSet.getString("Sname")+"\t"+
                                resultSet.getString("Sage")+"\t"+resultSet.getString("Sdept")+"\t"+resultSet.getString("Ssex")+"\n";
                    }
                    inform.setText("数据查询成功，已经显示在控制台窗口！\n"+"学号\t姓名\t\t年龄\t系别\t性别\n"+str);
                    SnoText.setText("");
                    SnameText.setText("");
                    SageText.setText("");
                    SdeptText.setText("");
                    SnoText.requestFocus();
                }
                catch (SQLException e1){
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
            }
            else if (course.isSelected()){
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    Statement statement;
                    ResultSet resultSet;
                    statement=connection.createStatement();
                    String cno=CnoText.getText();
                    String cname=CnameText.getText();
                    String preCourse=preCourseText.getText();
                    resultSet=statement.executeQuery("SELECT * FROM course where cno like '%"+cno+"%' and cname like '%"+cname+"%'" +
                            " and preCourse like '%"+preCourse+"%'");
                    String str="";
                    while (resultSet.next()){
                        str=str+resultSet.getString("Cno")+"\t"+resultSet.getString("Cname")+"\t"+
                                resultSet.getString("preCourse")+"\t"+resultSet.getString("Credit")+"\n";
                    }
                    inform.setText("数据查询成功，已经显示在控制台窗口！\n"+"课程号\t课程名\t\t先行课\t\t学分\n"+str);
                    CnoText.setText("");
                    CnameText.setText("");
                    preCourseText.setText("");
                    CreditText.setText("");
                    CnoText.requestFocus();
                }
                catch (SQLException e1){
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
            }
            else{
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    Statement statement;
                    ResultSet resultSet;
                    statement=connection.createStatement();
                    String scSno=scSnoText.getText();
                    String scCno=scCnoText.getText();
                    String str="";
                    resultSet=statement.executeQuery("SELECT * FROM sc where scSno like '%"+scSno+"%' and scCno like '%"+scCno+"%'");
                    while (resultSet.next()){
                        str=str+resultSet.getString("scSno")+"\t"+resultSet.getString("scCno")+"\t"+
                                resultSet.getString("Grade")+"\n";
                    }
                    inform.setText("数据查询成功，已经显示在控制台窗口！\n"+"学号\t课程号\t成绩\n"+str);
                    scSnoText.setText("");
                    scCnoText.setText("");
                    GradeText.setText("");
                    scSnoText.requestFocus();
                }
                catch (SQLException e1){
                    System.out.println("数据库连接错误"+"\n");
                    System.exit(0);
                }
            }
        }
    }
    class insert implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if (student.isSelected()){
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    studentInsert="INSERT INTO student VALUES(?,?,?,?,?)";
                    preInsert=connection.prepareStatement(studentInsert);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preInsert.setString(1,SnoText.getText());
                    preInsert.setString(2,SnameText.getText());
                    preInsert.setInt(3,Integer.parseInt(SageText.getText()));
                    preInsert.setString(4,SdeptText.getText());
//                    if (male.isSelected())
//                        studentsex="男";
//                    else
//                        studentsex="女";
                    if (s1.isSelected())
                        preInsert.setString(5,"男");
                    else
                        preInsert.setString(5,"女");
//                    preInsert.setString(5,studentsex);
                    preInsert.executeUpdate();
                    inform.setText("插入数据成功");
                    SnoText.setText("");
                    SnameText.setText("");
                    SageText.setText("");
                    SdeptText.setText("");
                    SnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    SnoText.requestFocus();
                }
            }
            else if (course.isSelected()){
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    courseInsert="INSERT INTO course VALUES(?,?,?,?)";
                    preInsert=connection.prepareStatement(courseInsert);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preInsert.setString(1,CnoText.getText());
                    preInsert.setString(2,CnameText.getText());
                    preInsert.setString(3,preCourseText.getText());
                    preInsert.setInt(4,Integer.parseInt(CreditText.getText()));
                    preInsert.executeUpdate();
                    inform.setText("插入数据成功");
                    CnoText.setText("");
                    CnameText.setText("");
                    preCourseText.setText("");
                    CreditText.setText("");
                    CnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    CnoText.requestFocus();
                }
            }
            else{
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    scInsert="INSERT INTO sc VALUES(?,?,?)";
                    preInsert=connection.prepareStatement(scInsert);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preInsert.setString(1,scSnoText.getText());
                    preInsert.setString(2,scCnoText.getText());
                    preInsert.setInt(3,Integer.parseInt(GradeText.getText()));
                    preInsert.executeUpdate();
                    inform.setText("插入数据成功");
                    scSnoText.setText("");
                    scCnoText.setText("");
                    GradeText.setText("");
                    scSnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    scSnoText.requestFocus();
                }
            }
        }
    }
    class update implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if (student.isSelected()){
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";// 数据源
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    studentUpdate="UPDATE student SET Sname=? WHERE Sno=?";
                    preUpdate=connection.prepareStatement(studentUpdate);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preUpdate.setString(1,SnameText.getText());
                    preUpdate.setString(2,SnoText.getText());
                    preUpdate.executeUpdate();
                    inform.setText("更新数据成功");
                    SnoText.setText("");
                    SnameText.setText("");
                    SageText.setText("");
                    SdeptText.setText("");
                    SnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    SnoText.requestFocus();
                }
            }
            else if (course.isSelected()){
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";// 数据源
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    courseUpdate="UPDATE course SET Cname=? WHERE Cno=?";
                    preUpdate=connection.prepareStatement(courseUpdate);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preUpdate.setString(1,CnameText.getText());
                    preUpdate.setString(2,CnoText.getText());
                    preUpdate.executeUpdate();
                    inform.setText("更新数据成功");
                    CnoText.setText("");
                    CnameText.setText("");
                    preCourseText.setText("");
                    CreditText.setText("");
                    CnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    CnoText.requestFocus();
                }
            }
            else {
                try{
                    String connectDB="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";// 数据源
                    String user="sa";
                    String password="sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    scUpdate="UPDATE sc SET Grade=? WHERE scSno=? AND scCno=?";
                    preUpdate=connection.prepareStatement(scUpdate);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preUpdate.setInt(1,Integer.parseInt(GradeText.getText()));
                    preUpdate.setString(2,scSnoText.getText());
                    preUpdate.setString(3,scCnoText.getText());
                    preUpdate.executeUpdate();
                    inform.setText("更新数据成功");
                    scSnoText.setText("");
                    scCnoText.setText("");
                    GradeText.setText("");
                    scSnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    scSnoText.requestFocus();
                }
            }
        }
    }
    class delete implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if (student.isSelected()){
                try{
                    String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user = "sa";
                    String password = "sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    studentDelete="DELETE FROM student WHERE Sno=?" ;
                    preDelete=connection.prepareStatement(studentDelete);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preDelete.setString(1,SnoText.getText());
                    preDelete.executeUpdate();
                    inform.setText("删除数据成功!");
                    SnoText.setText("");
                    SnameText.setText("");
                    SageText.setText("");
                    SdeptText.setText("");
                    SnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    SnoText.requestFocus();
                }
            }
            else if (course.isSelected()){
                try{
                    String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user = "sa";
                    String password = "sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    courseDelete="DELETE FROM course WHERE Cno=?" ;
                    preDelete=connection.prepareStatement(courseDelete);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preDelete.setString(1,CnoText.getText());
                    preDelete.executeUpdate();
                    inform.setText("删除数据成功!");
                    CnoText.setText("");
                    CnameText.setText("");
                    preCourseText.setText("");
                    CreditText.setText("");
                    CnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    CnoText.requestFocus();
                }
            }
            else {
                try{
                    String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=学生信息管理系统";
                    String user = "sa";
                    String password = "sa";
                    Connection connection=DriverManager.getConnection(connectDB, user, password);
                    scDelete="DELETE FROM sc WHERE scSno=? AND scCno=?" ;
                    preDelete=connection.prepareStatement(scDelete);
                    inform.setText("连接数据库成功"+"\n");
                }
                catch (SQLException e1) {
                    inform.setText("数据库连接错误"+"\n");
                    System.exit(0);
                }
                try{
                    preDelete.setString(1,scSnoText.getText());
                    preDelete.setString(2,scCnoText.getText());
                    preDelete.executeUpdate();
                    inform.setText("删除数据成功!");
                    scSnoText.setText("");
                    scCnoText.setText("");
                    GradeText.setText("");
                    scSnoText.requestFocus();
                }
                catch (Exception s2) {
                    inform.setText("输入数据有误！");
                    scSnoText.requestFocus();
                }
            }
        }
    }
    class WinClose extends WindowAdapter {
        public void windowClosing(WindowEvent e)
        {
            (e.getWindow()).dispose();
            System.exit(0);
        }
    }
}
