package JDB;

import java.sql.*;

public class javaConSQL {
    public static void main(String[] args) {
        String JDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";// SQL数据库引擎
        String connectDB = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=Mydb";// 数据源
        try {
            Class.forName(JDriver);// 加载数据库引擎，返回给定字符串名的类
            }
        catch (ClassNotFoundException e) {
            // e.printStackTrace();
            System.err.println("加载数据库引擎失败");
            System.exit(0);
            }
        System.out.println("数据库驱动成功");
        try {
            String user = "sa";
            String password = "sa";
            Connection con = DriverManager.getConnection(connectDB, user, password);// 连接数据库对象
            System.out.println("连接数据库成功");
            Statement stmt = con.createStatement();// 创建SQL命令对象
            // 创建表
            System.out.println("开始创建表");
            String query1 = "create table student (Sno NCHAR(10),Sname NCHAR(10),Sage INT,Sdept NCHAR(10),Ssex VARCHAR(50))";// 创建表SQL语句
            stmt.executeUpdate(query1);// 执行SQL命令对象
            String query2 = "create table course (Cno NCHAR(10),Cname NCHAR(10),preCourse NCHAR(10),Credit INT)";// 创建表SQL语句
            stmt.executeUpdate(query2);// 执行SQL命令对象
            String query3 = "create table sc (scSno NCHAR(10),scCno NCHAR(10),Grade INT)";// 创建表SQL语句
            stmt.executeUpdate(query3);// 执行SQL命令对象
            System.out.println("表创建成功");
            // 输入数据
            System.out.println("开始插入数据");
            String a1 = "INSERT INTO student VALUES('001','张三',19,'CS','男')";// 插入数据SQL语句
            String a2 = "INSERT INTO student VALUES('002','李四',20,'EE','男')";
            String a3 = "INSERT INTO student VALUES('003','王五',19,'BA','女')";
            stmt.executeUpdate(a1);// 执行SQL命令对象
            stmt.executeUpdate(a2);
            stmt.executeUpdate(a3);
            System.out.println("插入数据成功");
            // 读取数据
            System.out.println("开始读取数据");
            ResultSet rs = stmt.executeQuery("SELECT * FROM student");// 返回SQL语句查询结果集(集合)
            // 循环输出每一条记录
            while (rs.next()) {
            // 输出每个字段
                System.out.println(rs.getString("Sno") + "\t" + rs.getString("Sname")+ "\t" + rs.getString("Sage")
                        + "\t\t" + rs.getString("Sdept")+ "\t" + rs.getString("Ssex"));
            }
            System.out.println("读取完毕");
            // 关闭连接
            stmt.close();// 关闭命令对象连接
            con.close();// 关闭数据库连接
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.err.println("数据库连接错误");
            System.exit(0);
            }
    }
}
